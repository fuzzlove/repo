# Cr4shed 4.3.0 — 0-Sky iOS 27 Rootless Port

This folder contains the source-built, rootless Cr4shed package set for the 0-Sky iOS 27 SRD environment.

## Install order

1. `ws.hbang.common_2.0+0sky27.2_iphoneos-arm64.deb`
2. `com.muirey03.libmryipc_2.0.1+0sky27.2_iphoneos-arm64.deb`
3. `com.muirey03.cr4shed_4.3.0+0sky27.3_iphoneos-arm64.deb`

The Cr4shed package also requires the 0-Sky `ellekit` runtime already present on the device. After package installation, use 0-Sky Bridge/Link runtime sync so the app and daemon are admitted to the sealed Cryptex trust generation and register the app through appregistrard.

## iOS 27 adaptation

The historical package injected into ReportCrash, cfprefsd, and MobileGestaltHelper. Those paths produced deterministic crashes or loader rejection on iOS 27. This build removes those system injection payloads. Its privileged daemon imports native `.ips` reports into Cr4shed's log format and records `0SkyAdapter=ios27-native-ips` as evidence.

## Verification

Both an iPhone 12 (`iPhone13,2`) and iPhone SE 2020 (`iPhone12,8`) passed package integrity, APT dependency checks, sealed runtime trust, app registration, daemon activation, a controlled 0-Sky test-host crash import, and an 8-second foreground launch. Full reboot persistence was not rerun for this build, so the recorded UAT result is `PASS_WITH_WARNINGS`.

See `0sky-compat.json` for hashes, provenance, exact versions, and validation state. Source patches are under `patches/`.

Cr4shed upstream does not include a license file. Keep this derivative within the authorized private research environment unless redistribution rights are separately established.
